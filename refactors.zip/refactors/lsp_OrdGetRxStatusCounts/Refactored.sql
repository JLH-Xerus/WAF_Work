--/
Alter Procedure lsp_OrdGetRxStatusCounts

  @CountOnlyMostRecentRxForEachOrderId TinyInt = 1,
  @RangeIntoHistoryHrs Int,
  @AddrBankFilter VarChar(760) = Null,
  @ActiveRxOnly smallint = 0,
  @RxCntAwaitingWebTrx Int Output,
  @RxCntInitiated Int Output,
  @RxCntAwaitingScript Int Output,
  @RxCntAwaitingTransfer Int Output,
  @RxCntPosted Int Output,
  @RxCntNoRefillsRemain Int Output,
  @RxCntCallPrescriber Int Output,
  @RxCntFaxingPrescriber Int Output,
  @RxCntAwaitingReply Int Output,
  @RxCntFaxFailure Int Output,
  @RxCntApproved Int Output,
  @RxCntDenied Int Output,

  @RxCntGrpPending Int Output,
  @RxCntGrpScheduled Int Output,
  @RxCntProblem Int Output,
  @RxCntPending Int Output,
  @RxCntAwaitingMatch Int Output,
  @RxCntMatched Int Output,
  @RxCntOutForCentralFill Int Output,
  @RxCntScheduled Int Output,
  @RxCntSplit Int Output,
  @RxCntCounting  Int Output,
  @RxCntSuspended  Int Output,
  @RxCntPartialCounted Int Output,
  @RxCntCounted Int Output,
  @RxCntVialWait Int Output,
  @RxCntPartialFilled Int Output,
  @RxCntFilled Int Output,
  @RxCntChecked Int Output,
  @RxCntVerifying Int Output,
  @RxCntVerified Int Output,
  @RxCntInBin Int Output,
  @RxCntReadyForPickUp Int Output,
  @RxCntReadyToShip Int Output,
  @RxCntPickedUp Int Output,
  @RxCntShipPending Int Output,
  @RxCntShipped Int Output,
  @RxCntCanceled Int Output
As
----------------------------------------------------------------------------------------------------
-- Procedure:
--        lsp_OrdGetRxStatusCounts (refactor v2)
--
-- Description:
--        Retrieve the number of Rxs (including Rx Requests) within each status (pool).
--
-- Parameters:
--        @CountOnlyMostRecentRxForEachOrderId
--                           - Whether or not to count only the most recent Rx for each Order ID:
--                               1 = Count only the most recent Rx record for each Order ID.
--                               0 = Count all Rx records for each Order ID.
--        @RangeIntoHistoryHrs
--                           - The Range Into History Hours within which to count history Rxs.
--        @AddrBankFilter
--                           - The Bank(s) for which to count Rxs.
--		  @ActiveRxOnly
--							 - Whether or not to count inactive Rxs.
--								1 = Count only active Rxs
--								0 = Count All Rxs
--
-- Return Value:
--        @RxCntXXXXXXXXXX   - The number of Rxs (& Rx Requests) within the status (pool)
--                               where XXXXXXXXXX represents the status.
--
-- Comments:
--        A parent "Split" Rx has a "derived status" stored within its StatusReason field.
--        A parent "Split" Rx is considered as being in its "derived status" for these counts.
--        A permanent-split parent "Split" Rx is ignored in these counts (as well as in the results
--          on the Track Rx form).
--
-- Refactor Notes (v1 -> v2):
--   1. Replaced the WHILE-loop CSV parser for @AddrBankFilter with a single set-based INSERT
--      using STRING_SPLIT. Functionally equivalent, no per-iteration string allocation.
--   2. Converted the @RestrictAddrBank table variable to a #RestrictAddrBank temp table with
--      a clustered index on AddrBank. This gives the optimizer real cardinality (the table
--      variable always reported 1 row, regardless of contents) and makes the EXISTS probe a
--      seek instead of a 1-row-estimate join.
--   3. Fixed a pre-existing semantic bug in the EXISTS subquery. v1 had:
--          Exists (Select AddrBank From @RestrictAddrBank Where AddrBank = AddrBank)
--      Both AddrBank references resolved to the inner table (the @RestrictAddrBank column),
--      so the predicate evaluated to "AddrBank = AddrBank" which is true for every non-NULL
--      row in the filter table. The intended outer-table reference was silently lost.
--      The result: @AddrBankFilter had no effect. v2 qualifies both columns explicitly:
--          Exists (Select 1 From #RestrictAddrBank R Where R.AddrBank = O.AddrBank)
--      This restores the parameter's intended behavior. See Section 7 of Analysis.md for the
--      caller-impact discussion (callers passing a non-empty filter will now see a strict
--      subset of rows compared to v1).
--   4. Eliminated the 100-percent-duplicated SELECT block. v1 had two near-identical 38-CASE
--      aggregation blocks differing only in whether the OeOrderHistory branch joined to
--      OeOrderCurrHistoryDtTm. v2 builds the StatusCounts source once via a CTE that selects
--      the OeOrderHistory branch conditionally on @CountOnlyMostRecentRxForEachOrderId, then
--      runs the 38 SUM(CASE) aggregations exactly once.
----------------------------------------------------------------------------------------------------
Set NoCount On

------------------------------------------------------------------------------
-- Build the Address Bank Filter list (v2: temp table + STRING_SPLIT)
------------------------------------------------------------------------------
-- Was: Declare @RestrictAddrBank Table (AddrBank varchar(2)) (table variable).
-- Now: #temp table with a clustered index on AddrBank. The optimizer sees the real
-- row count after INSERT, which matters for the EXISTS probe in the StatusCounts CTE.
Drop Table If Exists #RestrictAddrBank

Create Table #RestrictAddrBank (AddrBank varchar(2) Not Null)

If @AddrBankFilter Is Not Null And @AddrBankFilter > ''
Begin

   -- Single set-based INSERT replaces the v1 WHILE loop.
   -- Trim each token in case the caller passes "BR, BL" with whitespace, and skip empty
   -- tokens caused by trailing or duplicated commas.
   Insert Into #RestrictAddrBank (AddrBank)
   Select Distinct LTrim(RTrim(value))
   From String_Split(@AddrBankFilter, ',')
   Where LTrim(RTrim(value)) > ''

End
Else
Begin

   -- Empty filter means "all banks". Mirror v1 by populating from BnkAllBanks.
   Insert Into #RestrictAddrBank (AddrBank)
   Select AddrBank
   From BnkAllBanks With (NoLock)

End

-- Clustered index supports the EXISTS lookup in the consolidated CTE below.
Create Clustered Index IX_RestrictAddrBank On #RestrictAddrBank (AddrBank)

------------------------------------------------------------------------------
-- Single SELECT block (v2: was duplicated in v1)
--
-- v1 had two 38-CASE aggregation blocks that differed only in whether the
-- OeOrderHistory branch joined to OeOrderCurrHistoryDtTm to keep only the most
-- recent history row per OrderId. v2 collapses both blocks into one CTE and
-- uses @CountOnlyMostRecentRxForEachOrderId as a conditional gate inside the
-- OeOrderHistory branch. The same row set is produced for either parameter
-- value, but the SQL text appears once.
--
-- Note on the EXISTS predicate: each branch references R.AddrBank against the
-- outer table's AddrBank column. v1's "Where AddrBank = AddrBank" was
-- self-comparison and silently always true. See Analysis.md Section 4 for
-- the bug description and Section 7 for the behavior change.
------------------------------------------------------------------------------
;With StatusCounts As
(
    -- Branch A: Open OeOrder rows. Excludes the legacy OrderId pattern that
    -- represents archived/migrated split portions.
    Select O.OrderStatus As Status, O.StatusReason
    From OeOrder O With (NoLock)
    Where O.OrderId Not Like '%[(<][1-8][)>]'
      And Exists (Select 1 From #RestrictAddrBank R Where R.AddrBank = O.AddrBank)

    Union All

    -- Branch B: OeOrderHistory rows within the lookback window.
    -- When @CountOnlyMostRecentRxForEachOrderId = 1, we constrain to the current
    -- HistoryDtTm per OrderId via OeOrderCurrHistoryDtTm. When = 0, we include
    -- every history row in the window. The Index(ByHistoryDtTm) hint is
    -- preserved from v1; revisit during v3 once the captured plan confirms
    -- whether it remains the optimizer's preference.
    Select OH.OrderStatus As Status, OH.StatusReason
    From OeOrderHistory OH With (NoLock, Index(ByHistoryDtTm))
    Left Join OeOrderCurrHistoryDtTm OC With (NoLock)
        On OC.OrderId = OH.OrderId
       And OC.HistoryDtTm = OH.HistoryDtTm
    Where OH.HistoryDtTm > DateAdd(Hour, -@RangeIntoHistoryHrs, GetDate())
      And Exists (Select 1 From #RestrictAddrBank R Where R.AddrBank = OH.AddrBank)
      And @ActiveRxOnly = 0
      -- "Most recent only" gate: when = 1, require the OC join to match.
      -- When = 0, the LEFT JOIN match is irrelevant and we accept all rows.
      And (   @CountOnlyMostRecentRxForEachOrderId = 0
           Or OC.OrderId Is Not Null )

    Union All

    -- Branch C: Open OeRxRequest rows.
    Select RR.Status, '' As StatusReason
    From OeRxRequest RR With (NoLock)
    Where RR.Status Not In ('Denied', 'Canceled')
      And Exists (Select 1 From #RestrictAddrBank R Where R.AddrBank = RR.AddrBank)

    Union All

    -- Branch D: Recently closed OeRxRequest rows within the lookback window.
    Select RR.Status, '' As StatusReason
    From OeRxRequest RR With (NoLock)
    Where RR.Status In ('Denied', 'Canceled')
      And RR.LastStsChgDtTm > DateAdd(Hour, -@RangeIntoHistoryHrs, GetDate())
      And Exists (Select 1 From #RestrictAddrBank R Where R.AddrBank = RR.AddrBank)
)
Select
    @RxCntAwaitingWebTrx       = Sum(Case When Status = 'Awaiting Web Trx'                                                          Then 1 Else 0 End),
    @RxCntInitiated            = Sum(Case When Status = 'Initiated'                                                                  Then 1 Else 0 End),
    @RxCntAwaitingScript       = Sum(Case When Status = 'Awaiting Script'                                                            Then 1 Else 0 End),
    @RxCntAwaitingTransfer     = Sum(Case When Status = 'Awaiting Transfer'                                                          Then 1 Else 0 End),
    @RxCntPosted               = Sum(Case When Status = 'Posted'                                                                     Then 1 Else 0 End),
    @RxCntNoRefillsRemain      = Sum(Case When Status = 'No Refills Remain'                                                          Then 1 Else 0 End),
    @RxCntCallPrescriber       = Sum(Case When Status = 'Call Prescriber'                                                            Then 1 Else 0 End),
    @RxCntFaxingPrescriber     = Sum(Case When Status = 'Faxing Prescriber'                                                          Then 1 Else 0 End),
    @RxCntAwaitingReply        = Sum(Case When Status = 'Awaiting Reply'                                                             Then 1 Else 0 End),
    @RxCntFaxFailure           = Sum(Case When Status = 'Fax Failure'                                                                Then 1 Else 0 End),
    @RxCntApproved             = Sum(Case When Status = 'Approved'                                                                   Then 1 Else 0 End),
    @RxCntDenied               = Sum(Case When Status = 'Denied'                                                                     Then 1 Else 0 End),
    @RxCntGrpPending           = Sum(Case When Status = 'Grp-Pending'                                                                Then 1 Else 0 End),
    @RxCntGrpScheduled         = Sum(Case When Status = 'Grp-Scheduled'                                                              Then 1 Else 0 End),
    @RxCntProblem              = Sum(Case When Status = 'Problem'                                                                    Then 1 Else 0 End),
    @RxCntPending              = Sum(Case When Status = 'Pending'         Or (Status Like 'Split-%' And StatusReason = 'Pending')         Then 1 Else 0 End),
    @RxCntAwaitingMatch        = Sum(Case When Status = 'Awaiting Match'                                                             Then 1 Else 0 End),
    @RxCntMatched              = Sum(Case When Status = 'Matched'                                                                    Then 1 Else 0 End),
    @RxCntOutForCentralFill    = Sum(Case When Status = 'Out For Central Fill'                                                       Then 1 Else 0 End),
    @RxCntScheduled            = Sum(Case When Status = 'Scheduled'       Or (Status Like 'Split-%' And StatusReason = 'Scheduled')       Then 1 Else 0 End),
    @RxCntSplit                = Sum(Case When Status Like 'Split-%'                                                                 Then 1 Else 0 End),
    @RxCntCounting             = Sum(Case When Status = 'Counting'        Or (Status Like 'Split-%' And StatusReason = 'Counting')        Then 1 Else 0 End),
    @RxCntSuspended            = Sum(Case When Status = 'Suspended'       Or (Status Like 'Split-%' And StatusReason = 'Suspended')       Then 1 Else 0 End),
    @RxCntPartialCounted       = Sum(Case When Status = 'Partial Counted' Or (Status Like 'Split-%' And StatusReason = 'Partial Counted') Then 1 Else 0 End),
    @RxCntCounted              = Sum(Case When Status = 'Counted'         Or (Status Like 'Split-%' And StatusReason = 'Counted')         Then 1 Else 0 End),
    @RxCntVialWait             = Sum(Case When Status = 'Vial Wait'       Or (Status Like 'Split-%' And StatusReason = 'Vial Wait')       Then 1 Else 0 End),
    @RxCntPartialFilled        = Sum(Case When Status = 'Partial Filled'  Or (Status Like 'Split-%' And StatusReason = 'Partial Filled')  Then 1 Else 0 End),
    @RxCntFilled               = Sum(Case When Status = 'Filled'          Or (Status Like 'Split-%' And StatusReason = 'Filled')          Then 1 Else 0 End),
    @RxCntChecked              = Sum(Case When Status = 'Checked'                                                                    Then 1 Else 0 End),
    @RxCntVerifying            = Sum(Case When Status = 'Verifying'                                                                  Then 1 Else 0 End),
    @RxCntVerified             = Sum(Case When Status = 'Verified'                                                                   Then 1 Else 0 End),
    @RxCntInBin                = Sum(Case When Status = 'In Bin'                                                                     Then 1 Else 0 End),
    @RxCntReadyForPickUp       = Sum(Case When Status = 'Ready For Pick Up'                                                          Then 1 Else 0 End),
    @RxCntReadyToShip          = Sum(Case When Status = 'Ready To Ship'                                                              Then 1 Else 0 End),
    @RxCntPickedUp             = Sum(Case When Status = 'Picked Up'                                                                  Then 1 Else 0 End),
    @RxCntShipPending          = Sum(Case When Status = 'Ship Pending'                                                               Then 1 Else 0 End),
    @RxCntShipped              = Sum(Case When Status = 'Shipped'                                                                    Then 1 Else 0 End),
    @RxCntCanceled             = Sum(Case When Status = 'Canceled'        Or (Status Like 'Split-%' And StatusReason = 'Canceled')        Then 1 Else 0 End)
From StatusCounts

Drop Table If Exists #RestrictAddrBank

/
