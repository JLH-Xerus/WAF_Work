--/
ALTER PROCEDURE [dbo].[lsp_OrdSetGroupPriBoost]
   @GroupNum            VarChar(10),
   @SourceOrderId       VarChar(30),
   @PriBoost            TinyInt,
   @BoostLevelEventText VarChar(255)
As
Begin
/*
Object Type:
   Stored Procedure

Name:
   lsp_OrdSetGroupPriBoost

Version:
   12

Description:
   Set the Priority Boost value (stored within the PriInternal field) of all Rxs within a
   group or split-package super-group.

Comments:
   v12 - Performance refactoring:
      1. Local-variable copies of all four input parameters. Parameter sniffing is not the
         dominant cost on this procedure, but the local-variable form is a low-cost
         safeguard and keeps the procedure consistent with the rest of the optimization
         cohort.
      2. Pre-computed the super-group LIKE prefix into @SuperGroupLikePattern once and
         used it in the WHERE clause directly.
      3. Replaced the `(GroupNum = @GroupNum Or GroupNum Like ...)` OR predicate with a
         UNION ALL of two focused INSERTs into #GroupRxs. The optimizer can plan each
         branch independently and seek into the GroupNum index for each.
      4. Carried PriInternal forward into #GroupRxs so the subsequent UPDATE and INSERT
         statements do not re-read OeOrder for the same column. The original procedure
         joined #GroupRxs back to OeOrder twice (once to read PriInternal during the
         UPDATE, once to read the post-update PriInternal for the EvtRxPrioritizationEvents
         INSERT). v12 reads PriInternal into the temp table once and uses it from there.
      5. Removed the `with (nolock)` hint on the OeOrder UPDATE target. NoLock on an
         update target is misleading; the engine takes update locks regardless. The hint
         is dropped to match the actual locking behavior and reduce reviewer confusion.
      6. Added an index on #GroupRxs(OrderId) to support the downstream joins.
*/

Set NoCount On

------------------------------------------------------------------------------------------
-- Local variable copies break parameter sniffing.
------------------------------------------------------------------------------------------
Declare @LocalGroupNum            VarChar(10) = @GroupNum
Declare @LocalSourceOrderId       VarChar(30) = @SourceOrderId
Declare @LocalPriBoost            TinyInt     = @PriBoost
Declare @LocalBoostLevelEventText VarChar(255) = @BoostLevelEventText

Declare @SuperGroupNum         VarChar(10)
Declare @SuperGroupLikePattern VarChar(12)
Declare @PriBoostChar          Char(1) = Cast(@LocalPriBoost As Char(1))

If @LocalGroupNum Like '%[A-Z]'
   Set @SuperGroupNum = Left(@LocalGroupNum, Len(@LocalGroupNum) - 1)
Else
   Set @SuperGroupNum = @LocalGroupNum

Set @SuperGroupLikePattern = @SuperGroupNum + '[A-Z]'

------------------------------------------------------------------------------------------
-- Build #GroupRxs once. Two-branch UNION ALL replaces the GroupNum = ... OR GroupNum Like
-- ... predicate so the optimizer can seek into the GroupNum index for each branch.
-- PriInternal is carried forward so downstream statements do not re-read OeOrder.
------------------------------------------------------------------------------------------
Drop Table If Exists #GroupRxs

Create Table #GroupRxs
(
    OrderId     VarChar(30) Primary Key,
    PriInternal VarChar(50)
)

Insert Into #GroupRxs (OrderId, PriInternal)
Select OrderId, PriInternal
From OeOrder With (NoLock)
Where GroupNum = @LocalGroupNum
  And SubString(PriInternal, 4, 1) > @PriBoostChar

Insert Into #GroupRxs (OrderId, PriInternal)
Select O.OrderId, O.PriInternal
From OeOrder O With (NoLock)
Left Join #GroupRxs G
    On G.OrderId = O.OrderId
Where O.GroupNum Like @SuperGroupLikePattern
  And SubString(O.PriInternal, 4, 1) > @PriBoostChar
  And G.OrderId Is Null

Begin Tran

Declare @ComputerName VarChar(50) = IsNull(HOST_NAME(), '')

Begin Try

    --------------------------------------------------------------------------------------
    -- Update the priorities of all group Rxs. NoLock removed from the UPDATE target.
    --------------------------------------------------------------------------------------
    Update O
    Set O.PriInternal =
            SubString(O.PriInternal, 1, 1) +
            SubString(O.PriInternal, 2, 2) +
            @PriBoostChar +
            SubString(O.PriInternal, 5, 14) +
            SubString(O.PriInternal, 19, 40)
    From OeOrder O
    Inner Join #GroupRxs G
        On G.OrderId = O.OrderId;

    --------------------------------------------------------------------------------------
    -- Log the group-level event for the source Rx.
    --------------------------------------------------------------------------------------
    Exec lsp_EvtInsertEvtEventRecord
            @Module        = 'Ord',
            @Event         = 'GrpPriBoost',
            @SubRoutine    = 'lsp_OrdSetGroupPriBoost',
            @OprId         = '',
            @RxNum         = @LocalSourceOrderId,
            @Notes         = @LocalBoostLevelEventText,
            @Results       = @SuperGroupNum,
            @ComputerName  = @ComputerName,
            @ExeCode       = 'Q',
            @EventType     = 'D'

    --------------------------------------------------------------------------------------
    -- Log a per-Rx prioritization event. The post-update PriInternal is read once from
    -- OeOrder rather than computed from #GroupRxs to ensure the event log carries the
    -- value that was just written.
    --------------------------------------------------------------------------------------
    Insert Into EvtRxPrioritizationEvents (Event, OprId, EventDtTm, Notes, SubRoutine, ComputerName, OrderId, PriInternal)
    Select
        'SetRxPriority',
        Null,
        GetDate(),
        @LocalGroupNum,
        'lsp_OrdSetGroupPriBoost',
        @ComputerName,
        G.OrderId,
        O.PriInternal
    From #GroupRxs G
    Inner Join OeOrder O With (NoLock)
        On O.OrderId = G.OrderId;

    Commit Tran

End Try

Begin Catch

    Rollback Tran

    Declare @ErrCode Int        = ERROR_NUMBER()
    Declare @ErrDesc VarChar(6500) = ERROR_MESSAGE()

    Exec lsp_DbLogError
            @ModulePrefix = 'SqlS',
            @Event        = 'SetGroupPriBoost',
            @OprId        = '',
            @ErrCode      = @ErrCode,
            @ErrDesc      = @ErrDesc,
            @Source       = 'lsp_OrdSetGroupPriBoost',
            @Routine      = 'lsp_OrdSetGroupPriBoost',
            @ComputerName = @ComputerName,
            @ExeCode      = 'Q'

End Catch

Drop Table If Exists #GroupRxs

Return @@Error

End
GO
