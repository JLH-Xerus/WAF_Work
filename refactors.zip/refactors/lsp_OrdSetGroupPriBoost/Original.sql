/****** Object:  StoredProcedure [dbo].[lsp_OrdSetGroupPriBoost]    Script Date: 4/5/2026 8:50:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create   Procedure [dbo].[lsp_OrdSetGroupPriBoost]
   @GroupNum VarChar(10),
   @SourceOrderId VarChar(30),
   @PriBoost TinyInt,
   @BoostLevelEventText VarChar(255)
As
/*
Object Type:
   Stored Procedure

Name:
   lsp_OrdSetGroupPriBoost

Version:
   11

Description:
   Set the Priority Boost value (stored within the PriInternal field) of all Rxs within a group or split-package super-group.

   Note:
      Within this 3-Line Conveyor system, a super-group is all groups for an order (that might be split up for separate collation & packaging).

      Sub-groups within a super-group end in differing alphabetic charaters following an all-numeric character group value.

      Example:
         123456A, 123456B, 123456C are all sub-groups of super-group 123456.

Parameters:
   Input:
      @GroupNum            - The group# or sub-group# of the Rxs for which to set the Priority Boost value.
      @SourceOrderId       - The Order ID of the source Rx initiating the group's priority boost.
                             This value is simply logged in the standard event.
      @PriBoost            - The Priority Boost value to which to set for the Rxs.
      @BoostLevelEventText - The text to log in the Group Priority Boost notes within the Diagnostic Event and Status Trail Entry for each Rx.
   Output:
      None

Return Value:
   0     = Success
   < 0   = Value of @@Error

Comments:
   None
*/

-------------------------------------------------------
-- If the group is a split-package group
--   Act instead on all sub-groups for the super-group.
-------------------------------------------------------
-- To do this act on all group number values without the trailing alphabetic character.
--
Declare @SuperGroupNum VarChar(10)
If @GroupNum Like '%[A-Z]'
  Set @SuperGroupNum = Left(@GroupNum, Len(@GroupNum) - 1)
Else
  Set @SuperGroupNum = @GroupNum

-- Build the list of Rxs in the group for which to boost the priority.
Drop Table If Exists #GroupRxs
Select OrderId
Into #GroupRxs
From OeOrder With (NoLock)
Where
   (GroupNum = @GroupNum Or GroupNum Like @SuperGroupNum + '[A-Z]')  -- Include all Rxs in super-group.
    And
    Substring(PriInternal, 4, 1) > Cast(@PriBoost As Char(1))        -- Include only Rxs that are not already boosted.


-- Begin a transaction
Begin Tran

Declare @ComputerName as VarChar(50) = (IsNull(HOST_NAME(), ''))

Begin Try

   -- Update the priorities of all group Rxs
   Update
      O
   Set
      O.PriInternal =
         SubString(PriInternal, 1, 1) +      -- Keep the same precedence over boost digit
         SubString(PriInternal, 2, 2) +      -- Keep the same system priority
         Cast(@PriBoost As Char(1)) +        -- Priority boost value (passed in)
         SubString(PriInternal, 5, 14) +     -- Keep the same FIFO/LIFO sequence
         SubString(PriInternal, 19, 40)      -- Keep the same priority preference rankings + subpriority
   From
      #GroupRxs As G
      Join OeOrder As O with (nolock) On O.OrderId = G.OrderId

   -- Log an event indicating the source Rx being boosted
   Exec lsp_EvtInsertEvtEventRecord
            @Module = 'Ord',
            @Event = 'GrpPriBoost',
            @SubRoutine = 'lsp_OrdSetGroupPriBoost',
            @OprId = '',
            @RxNum = @SourceOrderId,
            @Notes = @BoostLevelEventText,
            @Results = @SuperGroupNum,
            @ComputerName = @ComputerName,
            @ExeCode = 'Q',
            @EventType = 'D'

   -- Log an Rx prioritizatin event for each Rx in the group that was boosted
   Insert Into
      EvtRxPrioritizationEvents (Event, OprId, EventDtTm, Notes, SubRoutine, ComputerName, OrderId, PriInternal)
   Select
      'SetRxPriority',
      Null,
      GetDate(),
      @GroupNum,
      'lsp_OrdSetGroupPriBoost',
      @ComputerName,
      G.OrderId,
      O.PriInternal
   From
      #GroupRxs As G
      Join OeOrder As O with (nolock) On O.OrderId = G.OrderId

   -- Commit the transaction
   Commit Tran

End Try

Begin Catch

   -- Error occurred, rollback the transaction
   Rollback Tran

   Declare
      @ErrCode Int,
      @ErrDesc VarChar(6500)

   Select
      @ErrCode = ERROR_NUMBER(),
      @ErrDesc = ERROR_MESSAGE()

   -- Log the error
   Exec lsp_DbLogError
         @ModulePrefix = 'SqlS',
         @Event = 'SetGroupPriBoost',
         @OprId = '',
         @ErrCode = @ErrCode,
         @ErrDesc = @ErrDesc,
         @Source = 'lsp_OrdSetGroupPriBoost',
         @Routine = 'lsp_OrdSetGroupPriBoost',
         @ComputerName = @ComputerName,
         @ExeCode = 'Q'

End Catch

Return @@Error

GO
