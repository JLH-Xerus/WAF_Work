--/
ALTER PROCEDURE lsp_RbtDetermineNextVialToProcess
  @AddrBank VarChar(2),
  @InProcessTcdResets TinyInt,
  @InProcessCountDryRxsBeingFilled TinyInt,
  @TcdSn_ResetToIgnore_1 Int = 0,
  @TcdSn_ResetToIgnore_2 Int = 0
  As
/*
Object Type:
    Stored Procedure

Name:
    lsp_RbtDetermineNextVialToProcess

Version:
    11

Description:
    Determines the next Rx vial type to be processed by the robot.

Parameters:
    Input:
        @AddrBank - Robot bank name
        @InProcessTcdResets - The total number of Tcd resets currently being processed by the robot.
        @InProcessCountDryRxsBeingFilled - The total number of Count Dry Rxs being filled by the robot.
        @TcdSn_ResetToIgnore_1 - Dispenser SN of the dispenser for which the robot is currently processing a dispenser reset vial.
        @TcdSn_ResetToIgnore_2 - Dispenser SN of the dispenser for which the robot is currently reseting.
    Output:
        Recordset - Returns two Record sets

Return Value:
    None

Comments:
    This SP returns two datasets.
    First one contains the info for Vial type to process: Dispenser reset / Count Dry NON RX / Standard Rxs.
    Second is the main output that contains the details of the next vials to process depending upon the priority.

    v11 - Performance refactoring (2026-05-07):
        1. Consolidated the three top-of-proc Count(*) variable-assignment statements into
           a single conditional-aggregation Select over a Union All of the three sources.
           See [[Conditional Aggregation Consolidation]] (Flavor B). The three sources
           hit different tables, so leaf-level I/O is unchanged. The wins are one compile
           instead of three, one plan-cache slot instead of three, and one statement
           round-trip instead of three.
        2. Replaced the two-pass large-vial-availability check (an If Exists with a
           Top 1 ordered subquery as a correlated filter) with a single-pass conditional
           aggregation against RbtVialSupply. Computing both "max stored size" and "max
           stored size that is also available" in one pass tells us whether the largest
           vial is currently available without re-reading the table.
        3. Declared #temp_table2 with a clustered primary key on (ActOnAsPriInternal,
           PriInternal). This eliminates the heap sort that the v10 final Order By
           required and gives the optimizer statistics on the temp table. See
           [[Table Variables vs Temp Tables]] for the underlying principle.
        4. Replaced the v10 "Select * From #temp_table2" with an explicit column list
           that matches the temp-table declaration, removing the binding-time star
           expansion and protecting callers from any future column drift in
           lsp_OrdGetReadyForDispenseRxsInBank.

Debug SQL:

    Declare @return_value Int
    Exec @return_value = dbo.lsp_RbtDetermineNextVialToProcess
        @AddrBank = N'B',
        @InProcessTcdResets = 0,
        @InProcessCountDryRxsBeingFilled = 0,
        @TcdSn_ResetToIgnore_1 = 0,
        @TcdSn_ResetToIgnore_2 = 0
    Select 'Return Value' = @return_value

*/

Set NoCount On

Declare
    @TotalCountedRxs              Int = 0,
    @TotalCountedNONRxs           Int = 0,
    @TotalDispenserResetsRequired Int = 0,
    @LargeVialSizeAvailable       Bit = 0,
    @VialTypeToProcess            Int = 0

-- v11 change 1: Consolidated three Count(*) assignments into one statement.
-- Each Union All branch projects a 'Bucket' tag identifying which counter the
-- row contributes to; the outer Sum(Case When ...) aggregates the buckets into
-- the three local variables in a single round trip. Per-branch predicates are
-- preserved exactly as they were in v10. Leaf-level reads on the three sources
-- (OeOrder, TcdStatus + RvoNonRxProductVial, RbtQueuedForResetTcds + TcdStatus)
-- are unchanged: this is a Flavor B consolidation, not a Flavor A scan reduction.
Select
    @TotalCountedRxs              = Sum(Case When Bucket = 'CountedRxs'         Then 1 Else 0 End),
    @TotalCountedNONRxs           = Sum(Case When Bucket = 'CountedNONRxs'      Then 1 Else 0 End),
    @TotalDispenserResetsRequired = Sum(Case When Bucket = 'DispenserResets'    Then 1 Else 0 End)
From
(
    -- Bucket 1: Counted auto-fill Rxs eligible for processing in this bank.
    Select 'CountedRxs' As Bucket
    From OeOrder With (NOLOCK)
    Where AddrBank = @AddrBank
      And FillType = 'A'
      And OrderId Not Like '%<[1-2]>'                              -- Ignore Dual-Dispenser Portion/Children Rxs
      And Not OrderStatus Like 'Split_MV'                          -- Ignore Multi-Vial Parent Rxs (portions return as independent Rxs)
      And (
            OrderStatus In ('Counted', 'Partial Counted')          -- Counted Auto-Fill
            Or
            (OrderStatus = 'Split-DD' And StatusReason = 'Counted') -- Dual-Dispenser parent with both portions Counted
          )

    Union All

    -- Bucket 2: Counted Non-Rx product vials eligible for processing in this bank.
    Select 'CountedNONRxs' As Bucket
    From TcdStatus As T With (NOLOCK)
    Inner Join RvoNonRxProductVial As RNPV With (NOLOCK)
        On T.OrderId = RNPV.VialId
    Where T.AddrBank = @AddrBank
      And T.OrderId Like 'NONRX%'
      And (
            (T.Status = 'Online'  And T.DispMainState In (19, 2))                                        -- NON RX in Counted state
            Or
            (T.Status = 'Offline' And T.StatusReasonCode = 'Run Dry' And T.DispMainState = 2)            -- NON RX Partial Counted
          )
      And RNPV.StatusCode In ('N', 'P')                                                                  -- Counted or problem status

    Union All

    -- Bucket 3: Dispensers queued for reset in this bank with retries remaining,
    -- excluding the two TcdSn ignores supplied by the caller.
    Select 'DispenserResets' As Bucket
    From RbtQueuedForResetTcds As RT With (NOLOCK)
    Inner Join TcdStatus As T With (NOLOCK)
        On RT.TcdSn = T.TcdSn
    Where T.ProductId Is Not Null
      And RT.AddrBank = @AddrBank
      And RT.RemainingTries > 0
      And RT.TcdSn <> @TcdSn_ResetToIgnore_1
      And RT.TcdSn <> @TcdSn_ResetToIgnore_2
) As CountSources

-- Coalesce away the case where all three Count buckets are empty (Sum returns Null
-- when the Union All projects zero rows, but the variables still need to be 0 for
-- the comparisons below to be safe).
Set @TotalCountedRxs              = IsNull(@TotalCountedRxs, 0)
Set @TotalCountedNONRxs           = IsNull(@TotalCountedNONRxs, 0)
Set @TotalDispenserResetsRequired = IsNull(@TotalDispenserResetsRequired, 0)

/*--No Rxs to fill?*/
-- If there is nothing to process, return @VialTypeToProcess = 0.
If @TotalCountedRxs = 0 And @TotalCountedNONRxs = 0 And @TotalDispenserResetsRequired = 0
Begin
    Set @VialTypeToProcess = 0
    Select @VialTypeToProcess As VialTypeToProcess
    Return
End

-- v11 change 2: Single-pass large-vial-availability check.
-- v10 ran two passes against RbtVialSupply: an outer If Exists whose predicate
-- contained a correlated Top 1 / Order By subquery against the same table.
-- The single-pass form computes the global Max(StoredVialSizeDrams) for the bank
-- alongside the Max(StoredVialSizeDrams) restricted to rows whose StatusId is
-- 0 or 1 (available). The largest vial is available iff those two maxima are
-- equal. One scan, one comparison, one assignment.
Select @LargeVialSizeAvailable =
    Case
        When Max(StoredVialSizeDrams) Is Null Then 0
        When Max(Case When StatusId In (0, 1) Then StoredVialSizeDrams End) = Max(StoredVialSizeDrams) Then 1
        Else 0
    End
From RbtVialSupply With (NOLOCK)
Where AddrBank = @AddrBank

/*-PRIORITY 1*/
/*--Any dispenser requires a reset?*/
/*--Keep the number of In-process Tcd resets < 2 if there are other Rxs to be filled */
/*--Process only when large vial supply is available */
If ((@InProcessTcdResets < 2) Or (@TotalCountedRxs = 0 And @TotalCountedNONRxs = 0))
   And @TotalDispenserResetsRequired <> 0
   And @LargeVialSizeAvailable = 1
Begin
    Set @VialTypeToProcess = 1
    -- Return the final result (two datasets).
    Select
        @VialTypeToProcess            As VialTypeToProcess,
        @TotalCountedRxs              As TotalCountedRxs,
        @TotalCountedNONRxs           As TotalCountedNONRxs,
        @TotalDispenserResetsRequired As TotalDispenserResetsRequired,
        @LargeVialSizeAvailable       As LargeVialSizeAvailable

    Select
        RQT.TcdSn,
        RQT.RemainingTries,
        T.Status,
        T.AddrBank,
        T.AddrCabinet,
        T.AddrRow,
        T.AddrSlot,
        T.ProductId,
        T.QtyInBuffer,
        T.OrderId,
        T.StatusReasonCode,
        T.InvPool,
        IsNull(T.LastNdcReplenished, INV.FirstNdc) As Ndc,
        TS.CostPerPill
    From RbtQueuedForResetTcds As RQT With (NOLOCK)
    Inner Join TcdStatus           As T   With (NOLOCK) On RQT.TcdSn  = T.TcdSn
    Inner Join TcdSecondaryData    As TS  With (NOLOCK) On TS.TcdSn   = T.TcdSn
    Inner Join vInvMasterWithUserOverrides As INV With (NoLock)       On INV.ProductId = T.ProductId
    Where T.ProductId Is Not Null
      And RQT.AddrBank = @AddrBank
      And RQT.RemainingTries > 0
      And RQT.TcdSn <> @TcdSn_ResetToIgnore_1
      And RQT.TcdSn <> @TcdSn_ResetToIgnore_2
    Order By RQT.RemainingTries Desc, RQT.QueuedDtTm
    Return
End

/*-PRIORITY 2*/
/*--Any Count Dry NON RX Ready to be filled?*/
/*--Keep the number of In-process Count Dry Rxs being filled < 2 if there are standard Rxs that are waiting be filled */
/*--Process only when large vial supply is available */
Else If ((@InProcessCountDryRxsBeingFilled < 2) Or (@TotalCountedRxs = 0))
        And @TotalCountedNONRxs <> 0
        And @LargeVialSizeAvailable = 1
Begin
    Set @VialTypeToProcess = 2
    -- Return the final result (two datasets).
    Select
        @VialTypeToProcess            As VialTypeToProcess,
        @TotalCountedRxs              As TotalCountedRxs,
        @TotalCountedNONRxs           As TotalCountedNONRxs,
        @TotalDispenserResetsRequired As TotalDispenserResetsRequired,
        @LargeVialSizeAvailable       As LargeVialSizeAvailable

    Select
        T.OrderId,
        T.AddrBank,
        T.AddrCabinet,
        T.AddrRow,
        T.AddrSlot,
        T.TcdSn,
        T.ProductId,
        Case When RNPV.Qty > 0
             Then Cast(((RNPV.Qty * 100.0) / INV.QtyPer100Cc) * 0.2705 As Decimal(9, 3))
             Else 0
        End As ProductVolumeInDrams,
        INV.QtyPer100Cc,
        RNPV.Qty,
        RNPV.CreationDtTm
    From TcdStatus As T With (NOLOCK)
    Inner Join RvoNonRxProductVial         As RNPV With (NOLOCK) On T.OrderId   = RNPV.VialId
    Inner Join vInvMasterWithUserOverrides As INV  With (NoLock) On INV.ProductId = T.ProductId
    Where T.AddrBank = @AddrBank
      And T.OrderId Like 'NONRX%'
      And (
            (T.Status = 'Online'  And T.DispMainState In (19, 2))                                        -- NON RX in Counted state
            Or
            (T.Status = 'Offline' And T.StatusReasonCode = 'Run Dry' And T.DispMainState = 2)            -- NON RX Partial Counted
          )
      And RNPV.StatusCode In ('N', 'P')                                                                  -- Counted or problem status
    Return
End

/*-PRIORITY 3*/
/*--Any Regular Rx Ready to be filled?*/
/*For Regular Rxs the vial size is checked within RFM at this time.*/
If @TotalCountedRxs <> 0
Begin
    Set @VialTypeToProcess = 3

    -- v11 change 3: #temp_table2 declared with a clustered primary key on the
    -- final Order By columns (ActOnAsPriInternal, PriInternal). v10 created a
    -- heap and then sorted at read time; the indexed declaration lets the engine
    -- maintain the order during insert and stream the result without a sort
    -- operator. ActOnAsPriInternal + PriInternal is the natural composite key
    -- because Order By on those columns is the only consumer of the temp table.
    -- If lsp_OrdGetReadyForDispenseRxsInBank ever returns duplicates on that
    -- composite, downgrade to a non-unique clustered index. PrimaryKey is used
    -- here on the assumption that the existing v10 result set never carries
    -- duplicate (ActOnAsPriInternal, PriInternal) pairs; this is worth confirming
    -- during the validation run.
    Drop Table If Exists #temp_table2

    Create Table #temp_table2
    (
        OrderId                          VarChar(30),
        ProductId                        VarChar(20),
        FillToMakeWayForUpstreamRxOrderId VarChar(50),
        QtyOrdered                       Decimal(9, 3),
        QtyPer100cc                      SmallInt,
        ProductVolumeInDrams             Decimal(9, 3),
        OverFlowLabelRequired            Bit,
        ActOnAsPriInternal               VarChar(40) Not Null,
        PriInternal                      VarChar(40) Not Null,
        Constraint PK_TempTable2_ActOnAsPriInternal_PriInternal
            Primary Key Clustered (ActOnAsPriInternal, PriInternal)
    )

    Insert Into #temp_table2
        (OrderId, ProductId, FillToMakeWayForUpstreamRxOrderId, QtyOrdered,
         QtyPer100cc, ProductVolumeInDrams, OverFlowLabelRequired,
         ActOnAsPriInternal, PriInternal)
    Exec lsp_OrdGetReadyForDispenseRxsInBank @AddrBank, 0

    -- Return the final result (two datasets).
    -- v11 change 4: explicit column list replaces v10's Select *. Order By is
    -- preserved verbatim; it is now a no-cost ordering because the clustered
    -- key already streams the rows in the requested order, but keeping the
    -- Order By documents the intended row order for callers.
    Select
        @VialTypeToProcess            As VialTypeToProcess,
        @TotalCountedRxs              As TotalCountedRxs,
        @TotalCountedNONRxs           As TotalCountedNONRxs,
        @TotalDispenserResetsRequired As TotalDispenserResetsRequired,
        @LargeVialSizeAvailable       As LargeVialSizeAvailable

    Select
        OrderId,
        ProductId,
        FillToMakeWayForUpstreamRxOrderId,
        QtyOrdered,
        QtyPer100cc,
        ProductVolumeInDrams,
        OverFlowLabelRequired,
        ActOnAsPriInternal,
        PriInternal
    From #temp_table2 With (NOLOCK)
    Order By ActOnAsPriInternal, PriInternal

    Drop Table If Exists #temp_table2
    Return
End

/*--No Rxs to fill due to unavailable vial supply?*/
/*--Catches cases where there are dispenser resets and count-dry rxs to process but the robot does not have a large vial size.*/
Else If @TotalCountedRxs = 0
        And ((@TotalDispenserResetsRequired <> 0 And @LargeVialSizeAvailable = 0)
             Or
             (@TotalCountedNONRxs <> 0 And @LargeVialSizeAvailable = 0))
Begin
    Set @VialTypeToProcess = -1
    Select
        @VialTypeToProcess            As VialTypeToProcess,
        @TotalCountedRxs              As TotalCountedRxs,
        @TotalCountedNONRxs           As TotalCountedNONRxs,
        @TotalDispenserResetsRequired As TotalDispenserResetsRequired,
        @LargeVialSizeAvailable       As LargeVialSizeAvailable
    Return
End

/*--The execution should never reach here; safety case to surface unexpected combinations.*/
Set @VialTypeToProcess = -99
Select
    @VialTypeToProcess            As VialTypeToProcess,
    @TotalCountedRxs              As TotalCountedRxs,
    @TotalCountedNONRxs           As TotalCountedNONRxs,
    @TotalDispenserResetsRequired As TotalDispenserResetsRequired,
    @LargeVialSizeAvailable       As LargeVialSizeAvailable

/
