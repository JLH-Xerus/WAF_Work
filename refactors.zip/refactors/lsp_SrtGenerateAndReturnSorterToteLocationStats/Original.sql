/****** Object:  StoredProcedure [dbo].[lsp_SrtGenerateAndReturnSorterToteLocationStats]    Script Date: 4/5/2026 8:50:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[lsp_SrtGenerateAndReturnSorterToteLocationStats]
	@NumAssignedTotes Int Output,
	@NumUnassignedTotes Int Output,
	@NumFullTotes Int Output,
	@NumOfExceptPkgs Int Output,
	@NumOfPackagesInductedAndUnsorted Int Output
As

----------------------------------------------------------------------------------------------------
-- Procedure:
--        lsp_SrtGenerateAndReturnSorterToteLocationStats
--
-- Description:
--        Generate the tote/location stats: 
--        1) Number of Exception Packages that reside in Sorter Location Shipping Totes.
--        2) Number of full totes.
--        3) Number of assigned locations.
--        4) Number of unassigned locations.
--        5) Number of packages inducted into sorter but not added to totes.
--
-- Parameters:
--        None
--
-- Return Value:
--        None
--
-- Comments:
--        None
--
----------------------------------------------------------------------------------------------------


Declare @ToteFullPackageCount SmallInt

-----------------------------------------------------------------------------
-- Retrieve a list of Order ID / History Date/Time / Shipment ID combinations
--   of the Rxs in Packages residing in Sorter Totes.
-----------------------------------------------------------------------------
-- Do this once.  It will be used to interrogate both Active & History Rxs for such Rxs/Packages.
--
Set NoCount On

If Object_Id('TempDb..#SorterTotePackageRxs') Is Not Null
	Drop Table #SorterTotePackageRxs

Select
	OS.OrderId,
	OS.HistoryDtTm,
	OS.ShipmentId
Into
	#SorterTotePackageRxs
From
	SrtSorterLoc As L With (NoLock)
		Join
	SrtShipToteShipmentAssoc As TS With (NoLock)
		On TS.ShipToteId = L.ShipToteId             -- Include Packages (Shipments) in Sorter Location Totes.
		Join
	OeOrderShipmentAssoc As OS With (NoLock)
		On OS.ShipmentId = TS.ShipmentId
Option(MaxDop 1)

-----------------------------------------------------------
-- Retrieve a list of Exception Rx Packages (Shipment IDs).
-----------------------------------------------------------
-- The Active and History Exception Rx Packages are handle separately because
--   it is more efficient to acquire each of these in a different way.
--
-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
-- For the Active Rxs, key on Order Status (equals "Problem").
-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
If Object_Id('TempDb..#ActiveExceptionRxPackageShipmentIds') Is Not Null
	Drop Table #ActiveExceptionRxPackageShipmentIds

Select
	Distinct(SR.ShipmentId) As ShipmentId
Into
	#ActiveExceptionRxPackageShipmentIds
From
	OeOrder As O With (NoLock)
		Join
	#SorterTotePackageRxs As SR
		On SR.OrderId = O.OrderId And SR.HistoryDtTm = O.HistoryDtTm
Where
	O.OrderStatus = 'Problem'               -- Include Packages (Shipments) having an Active Rx in "Problem" Status.

-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
-- For the History Rxs, key on "History Rx is in a Sorter Tote Package".
-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
If Object_Id('TempDb..#HistoryExceptionRxPackageShipmentIds') Is Not Null
	Drop Table #HistoryExceptionRxPackageShipmentIds

--
-- Leaving out the OrderStatus filter for part 1 avoids SQL Server keying on that index for "All History records".
--
Select
	SR.ShipmentId,
	O.OrderStatus
Into
	#HistoryExceptionRxPackageShipmentIds
From
	#SorterTotePackageRxs As SR
		Join
	OeOrderHistory As O With (NoLock)
		On O.OrderId = SR.OrderId And O.HistoryDtTm = SR.HistoryDtTm
Where
	SR.HistoryDtTm <> '12/31/9999'

-- - - - - - - - - - - - - - - - - - - - - - - - - -
-- Then, only keep "Canceled" Status History cases.
-- - - - - - - - - - - - - - - - - - - - - - - - - -
-- Following suit with pre-existing, explicit logic.
-- However, there really should not be any cases of other history ("Shipped") status Rxs in Sorter Tote Packages.
--
Delete
From
	#HistoryExceptionRxPackageShipmentIds
Where
	OrderStatus <> 'Canceled'

------------------------------------------------------------------------------------------
-- Retrieve the final list of Shipment IDs of Exception Packages residing in Sorter Totes.
------------------------------------------------------------------------------------------
Set NoCount Off

If Object_Id('TempDb..#NumOfExceptPkgs') Is Not Null
	Drop Table #NumOfExceptPkgs

Select
	Count(Distinct(ShipmentId)) As NumOfExceptPkgs
Into 
	#NumOfExceptPkgs
From
	(
		Select
			ShipmentId
		From
			#ActiveExceptionRxPackageShipmentIds

		Union

		Select
			ShipmentId
		From
			#HistoryExceptionRxPackageShipmentIds

	) As ExceptPkgShipIds

------------------------------------------------------------------------------------------------------------------
--Get number of packages inducted into sorter, routed to locations, but still not added to totes after one minute.
------------------------------------------------------------------------------------------------------------------
If Object_Id('TempDb..#AllShipmentIds') Is Not Null
	Drop Table #AllShipmentIds

If Object_Id('TempDb..#NumOfPackagesInducted') Is Not Null
	Drop Table #NumOfPackagesInducted

If Object_Id('TempDb..#NumOfPackagesInductedAndUnsorted') Is Not Null
	Drop Table #NumOfPackagesInductedAndUnsorted

--Get all packages
Select 
	ShipmentId,
	CurrLoc,
	NextLoc,
	LastLocChgDtTm
Into
	#AllShipmentIds
From
	OeOrderShipmentAssoc As OSA With (NoLock)
		Join
	OeOrder As O With (NoLock)
		On OSA.OrderId = O.OrderId And OSA.HistoryDtTm = O.HistoryDtTm
		Join
	ShpShipment As SP With (NoLock)
		On OSA.ShipmentId = SP.Id
		Join
	CvyRxRoute As CRR With (NoLock)
		On O.OrderId = CRR.OrderId And O.HistoryDtTm = CRR.HistoryDtTm

----------------------------------------------------------------------------------------------------------------
--Get the number of packages inducted into sorter. 
----------------------------------------------------------------------------------------------------------------
Select
	Count(*) As NumOfPackagesInducted,
	SI.LastLocChgDtTm As InductedDtTm,
	SI.ShipmentId
Into
	#NumOfPackagesInducted
From
	#AllShipmentIds As SI With (NoLock) 
Where
	Left(SI.CurrLoc,4) = 'SORT'
		And
	Left(SI.NextLoc,2) = 'DR'
Group By
	SI.LastLocChgDtTm,
	SI.ShipmentId

----------------------------------------------------------------------------------------------------------------
--Get the number of packages still not added to totes after one minute from induction.
----------------------------------------------------------------------------------------------------------------
Select
	Count(*) As NumOfPackagesInductedAndUnsorted
Into
	#NumOfPackagesInductedAndUnsorted
From
	#NumOfPackagesInducted As PI With (NoLock)
Where
	PI.ShipmentId Not In (
	Select
		TSA.ShipmentId
	From
		SrtShipToteShipmentAssoc As TSA With (NoLock)
	)
	And
		DateDiff (SECOND, PI.InductedDtTm, GetDate()) > 60

---------------------------------------------------
--Main Query
---------------------------------------------------

-----------------------------------------------------------------------------------------------------------------
-- Get the configuration parameter setting value for ShippingToteFullPackageCount from CfgSystemParamValue table.
-----------------------------------------------------------------------------------------------------------------
Select
	@ToteFullPackageCount = Cast (Value As SmallInt)
From
	CfgSystemParamVal WITH (Nolock)
Where
	Section = 'PackageSorter'
		And
	Parameter = 'ShippingToteFullPackageCount'

Select
	@NumAssignedTotes = Sum(NumAssignedTotes),
	@NumUnassignedTotes = Sum(UnassignedTotes),
	@NumFullTotes = Sum(FullTotes), 
	@NumOfExceptPkgs = Sum(NumOfExceptPkgs), 
	@NumOfPackagesInductedAndUnsorted = Sum(NumOfPackagesInductedAndUnsorted)
From
(

	--Retrieve the number of full totes.
	Select
		Count(Id) As FullTotes,
		'' As NumAssignedTotes,
		'' As UnassignedTotes,
		'' As NumOfExceptPkgs,
		'' As NumOfPackagesInductedAndUnsorted
	From
		SrtShipTote WITH (NOLOCK)
	Where
		NumOfPkgs >= @ToteFullPackageCount
		And
		Len(Id) = 22
		And
		Status <> 'Ready For Manifest'

	UNION
	--Retrieve the number of totes assigned to locations.
	Select
		'' As FullTotes,
		Count(SL.ShipToteId) As NumAssignedTotes,
		'' As UnassignedTotes,
		'' As NumOfExceptPkgs,
		'' As NumOfPackagesInductedAndUnsorted
	From
		SrtSorterLoc As SL With (NoLock)
			Join
		SrtShipTote As ST With (NoLock)
			On SL.ShipToteId = ST.Id
	Where
		ST.Status In ('In Sorter Loc')
			And
		Len(ST.Id) = 22

	UNION
	--Retrieve only the sorter locations which are assigned to stores but without totes being opened for those.
	Select
		'' As FullTotes,
		'' As NumAssignedTotes,
		Count (Distinct SL.Id) As UnassignedTotes,
		'' As NumOfExceptPkgs,
		'' As NumOfPackagesInductedAndUnsorted
	From
		SrtSorterLoc As SL With (NOLOCK)
	Where
		SL.CarrierCode Is Not Null
			And
		SL.HasTote = 0

	UNION
	--Retrieve the number of exception packages in all totes.
	Select	
		'' As FullTotes,
		'' As NumAssignedTotes,
		'' As UnassignedTotes,
		NumOfExceptPkgs,
		'' As NumOfPackagesInductedAndUnsorted
	From
		#NumOfExceptPkgs

	UNION
	--Retrieve the number of packages inducted into sorter but not added to totes.
		Select	
		'' As FullTotes,
		'' As NumAssignedTotes,
		'' As UnassignedTotes,
		'' As NumOfExceptPkgs,
		NumOfPackagesInductedAndUnsorted
	From
		#NumOfPackagesInductedAndUnsorted
) As T


GO
