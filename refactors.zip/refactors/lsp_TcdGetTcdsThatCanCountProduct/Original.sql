/****** Object:  StoredProcedure [dbo].[lsp_TcdGetTcdsThatCanCountProduct]    Script Date: 4/5/2026 8:50:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[lsp_TcdGetTcdsThatCanCountProduct]
	@ProductId VarChar(11),
	@AddrBank VarChar(2),
	@InvPool TinyInt = 0,
	@CountQty Int,
	@MatchingNdc VarChar(20) = ''
As
----------------------------------------------------------------------------------------------------
-- Procedure:
--        lsp_TcdGetTcdsThatCanCountProduct
--
-- Version:
--		  17
--
-- Description:
--        Retrieve a list of dispensers that can count a specified product.
--
--        Order the dispenser list as follows:
--          - Sufficient (hopper) quantity to count desired quantity first.
--            - Within this category, least (hopper) quantity first.
--          - Insufficient (hopper) quantity to count desired quantity next.
--            - Within this category, least (hopper) quantity first.
--
-- Parameters:
--        @ProductId   - The ID of the product for which to retrieve the dispensers.
--        @AddrBank    - The cabinet bank within which to retrieve the dispensers.
--        @InvPool     - The inventory pool within which to retrieve the dispensers.
--                       Pass 0, to ignore inventory pool (i.e., if inventory polling is disabled).
--        @CountQty    - The target quantity of pills to be counted in a dispenser.
--                       This value simply affects the order of the resulting list of dispensers.
--                       (See Description section.)
--        @MatchingNdc - (optional) require dispenser Last Replenished NDC matches this NDC.
--
-- Return Value:
--        None
--
-- Comments:
--        When the TCD Controller Count Launcher chooses a dispenser to count an Rx (or Rx portion),
--          it favors the same-product dispenser that has the least, but sufficient quantity.
--
----------------------------------------------------------------------------------------------------
Select
	T.AddrCabinet,
	T.AddrRow,
	T.AddrSlot,
	T.TcdSn,
	T.TcdModel,
	T.QtyInHopper,
	T.QtyInBuffer,
	T.EpromVersion,
	ISNULL(T.EarliestExpDate,
	       (Select Top 1 L.ExpireDate From CanCanister As C Join CanLotCode As L On L.CanisterSn = C.CanisterSn Where C.TcdSn = T.TcdSn Order By L.ExpireDate)
			 ) As EarliestExpDate,
	ISNULL(TS.OldestLotInitReplenDtTm,
	       (Select Top 1 L.LastAddDtTm From CanCanister As C Join CanLotCode As L On L.CanisterSn = C.CanisterSn Where C.TcdSn = T.TcdSn Order By L.LastAddDtTm)
			 ) As OldestLotInitReplenDtTm,
	T.InUse,
	T.NdcParamChg,
	Case When T.QtyInHopper >= @CountQty Then 1 Else 0 End As HasSuffQty,
   T.LocCanModel 
From
	TcdStatus As T With (NoLock)
		Left Join
	TcdSecondaryData As TS With (NoLock)
		On T.TcdSn = TS.TcdSn
		Left Outer Join
	TcdDryDispensers As TDD With (NoLock)
		On TDD.TcdSn = T.TcdSn
		Left Join
	TcdFlaggedTcds As TFT With (NOLOCK) 
		On TFT.TcdSn = T.TcdSn 
Where
	T.ProductId = @ProductId
	And
	T.AddrBank = @AddrBank
	And
	(T.InvPool = @InvPool Or @InvPool = 0)
	And
	T.Status = 'Online'
	And
	T.TcdState = 'Tcd Initialized.'
	And
	T.LocationState = 'Initialized Location.'
	And
	IsNull(T.LastNdcReplenished, '') = Case When Len(@MatchingNdc) > 0 Then @MatchingNdc Else IsNull(T.LastNdcReplenished, '') End
	And
	TDD.TcdSn Is Null					-- Exclude all Run Dry dispensers
	And
	(TFT.IsFlaggedFor Is NULL Or TFT.IsFlaggedFor NOT IN ('Count Dry Unassign','Count Dry Inv Count'))  -- Exclude all dispensers flagged for count dry
Order By
	HasSuffQty Desc,
	T.QtyInHopper
GO
