--/
ALTER PROCEDURE [dbo].[lsp_TcdGetTcdsThatCanCountProduct]
   @ProductId   VarChar(11),
   @AddrBank    VarChar(2),
   @InvPool     TinyInt = 0,
   @CountQty    Int,
   @MatchingNdc VarChar(20) = ''
As
Begin
/*
Object Type:
   Stored Procedure

Name:
   lsp_TcdGetTcdsThatCanCountProduct

Version:
   18

Comments:
   v18 - Performance refactoring:
      1. Local-variable copies of all five input parameters.
      2. Pre-materialized the per-Tcd lot-aggregate fallbacks (EarliestExpDate and
         OldestLotInitReplenDtTm) into one temp table built via a single pass over
         CanCanister + CanLotCode for the candidate Tcds. The original procedure
         used two correlated Top 1 scalar subqueries that executed per outer row.
      3. Replaced the two catch-all parameter predicates with explicit conditional
         WHERE shapes:
            - `(T.InvPool = @InvPool Or @InvPool = 0)` is rewritten so the InvPool
              filter is only applied when @LocalInvPool <> 0. The local-variable
              form plus Option (Recompile) lets the optimizer simplify the no-filter
              branch at compile time.
            - `IsNull(T.LastNdcReplenished, '') = Case When Len(@MatchingNdc) > 0 ...`
              is rewritten as a conditional predicate (`@LocalMatchingNdc = '' Or
              T.LastNdcReplenished = @LocalMatchingNdc`). Same simplification benefit
              under Recompile.
      4. Added Option (Recompile). The procedure is called at high frequency, so the
         per-call compile cost is non-trivial. The cross-list capture's "high-volume
         / sub-ms" classification means Recompile should be evaluated post-deployment
         for whether the compile cost exceeds the plan-quality benefit; the local-
         variable form alone is the fallback if Recompile is too expensive.
*/

Set NoCount On

------------------------------------------------------------------------------------------
-- Local variables.
------------------------------------------------------------------------------------------
Declare @LocalProductId   VarChar(11) = @ProductId
Declare @LocalAddrBank    VarChar(2)  = @AddrBank
Declare @LocalInvPool     TinyInt     = IsNull(@InvPool, 0)
Declare @LocalCountQty    Int         = @CountQty
Declare @LocalMatchingNdc VarChar(20) = IsNull(@MatchingNdc, '')

Drop Table If Exists #CandidateTcds, #TcdLotFallbacks

------------------------------------------------------------------------------------------
-- Identify the candidate Tcds in one pass. This narrows the row set for the lot-aggregate
-- pre-materialization in the next step.
------------------------------------------------------------------------------------------
Select
      T.TcdSn
    , T.AddrCabinet, T.AddrRow, T.AddrSlot, T.TcdModel
    , T.QtyInHopper, T.QtyInBuffer, T.EpromVersion
    , T.EarliestExpDate
    , T.InUse, T.NdcParamChg, T.LocCanModel
    , [TS_OldestLotInitReplenDtTm] = TS.OldestLotInitReplenDtTm
Into #CandidateTcds
From TcdStatus T With (NoLock)
Left Join TcdSecondaryData TS With (NoLock)
    On TS.TcdSn = T.TcdSn
Left Join TcdDryDispensers TDD With (NoLock)
    On TDD.TcdSn = T.TcdSn
Left Join TcdFlaggedTcds TFT With (NoLock)
    On TFT.TcdSn = T.TcdSn
Where T.ProductId    = @LocalProductId
  And T.AddrBank     = @LocalAddrBank
  And T.Status       = 'Online'
  And T.TcdState     = 'Tcd Initialized.'
  And T.LocationState = 'Initialized Location.'
  And TDD.TcdSn Is Null
  And (TFT.IsFlaggedFor Is Null Or TFT.IsFlaggedFor Not In ('Count Dry Unassign', 'Count Dry Inv Count'))
  And (@LocalInvPool = 0 Or T.InvPool = @LocalInvPool)
  And (@LocalMatchingNdc = '' Or IsNull(T.LastNdcReplenished, '') = @LocalMatchingNdc)
Option (Recompile);

Create Index IX_Cand_TcdSn On #CandidateTcds(TcdSn)

------------------------------------------------------------------------------------------
-- Pre-materialize lot-aggregate fallbacks for the candidate Tcds.
------------------------------------------------------------------------------------------
Select
      C.TcdSn
    , [FallbackEarliestExpDate]            = Min(L.ExpireDate)
    , [FallbackOldestLotInitReplenDtTm]    = Min(L.LastAddDtTm)
Into #TcdLotFallbacks
From #CandidateTcds CT
Inner Join CanCanister C With (NoLock)
    On C.TcdSn = CT.TcdSn
Inner Join CanLotCode L With (NoLock)
    On L.CanisterSn = C.CanisterSn
Group By C.TcdSn

Create Index IX_LotFb_TcdSn On #TcdLotFallbacks(TcdSn)

------------------------------------------------------------------------------------------
-- Final SELECT with the same shape as v17 but with the fallbacks joined in.
------------------------------------------------------------------------------------------
Set NoCount Off

Select
      CT.AddrCabinet
    , CT.AddrRow
    , CT.AddrSlot
    , CT.TcdSn
    , CT.TcdModel
    , CT.QtyInHopper
    , CT.QtyInBuffer
    , CT.EpromVersion
    , [EarliestExpDate]         = IsNull(CT.EarliestExpDate, FB.FallbackEarliestExpDate)
    , [OldestLotInitReplenDtTm] = IsNull(CT.TS_OldestLotInitReplenDtTm, FB.FallbackOldestLotInitReplenDtTm)
    , CT.InUse
    , CT.NdcParamChg
    , [HasSuffQty]              = Case When CT.QtyInHopper >= @LocalCountQty Then 1 Else 0 End
    , CT.LocCanModel
From #CandidateTcds CT
Left Join #TcdLotFallbacks FB
    On FB.TcdSn = CT.TcdSn
Order By
      HasSuffQty Desc
    , CT.QtyInHopper

Drop Table If Exists #CandidateTcds, #TcdLotFallbacks

End
GO
