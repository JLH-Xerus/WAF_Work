--/
ALTER PROCEDURE [dbo].[lsp_OeOrderTextDocumentsClassify]
   @BatchSize  Int = 100,
   @MaxRecords Int = 1000
As
Begin
/*
Object Type:
   Stored Procedure

Object Name:
   lsp_OeOrderTextDocumentsClassify

Version:
   2

Description:
   Classify OeOrderTextDocument rows from the secondary node into the local
   OeOrderTextDocumentClassification table as Leaflet (DocDataLength <= 153,600) or
   Non-Leaflet (DocDataLength > 153,600). Processes up to @MaxRecords rows per call
   in batches of @BatchSize.

Comments:
   v2 - Performance refactoring:
      1. Local-variable copies of @BatchSize and @MaxRecords.
      2. Replaced the WHILE EXISTS check against the linked-server tables with a
         @@ROWCOUNT-based loop. The WHILE EXISTS executed a separate linked-server
         round-trip on every iteration to ask whether there was more work; the
         @@ROWCOUNT approach reads the row count directly from the immediately-
         preceding INSERT statement.
      3. Track @LastProcessedId in-memory rather than re-reading the local
         classification table on every iteration. The initial value comes from one
         read at the top of the procedure; each iteration's INSERT projects the
         current batch's Max(Id) which we update in-memory.
      4. Removed the stray `SELECT @LastProcessedId` (line 30 in v1) and `SELECT
         @TotalProcessed` (line 73 in v1) statements. Both returned single-value
         result sets to the caller per iteration. Almost certainly debug artifacts.
      5. Moved the @MaxRecords check into the loop condition rather than as a
         break-from-inside-body shape.
      6. The linked-server reads (the WHILE check in v1 and the batch SELECT) are
         preserved consistently in v2. Both run against the secondary node by design
         (see Section 11.1 of Analysis.md for the cross-reference to Row 35's
         linked-server question).
*/

Set NoCount On

Declare @LocalBatchSize  Int = @BatchSize
Declare @LocalMaxRecords Int = @MaxRecords

Declare @CutoffDate      DateTime = DateAdd(Day, -28, GetDate())
Declare @TotalProcessed  Int = 0
Declare @InsertedThisPass Int = 0
Declare @LastProcessedId Int
Declare @ContinueLoop    Bit = 1

Declare @ErrorMessage    NVarChar(4000)
Declare @ErrorSeverity   Int
Declare @ErrorState      Int
Declare @EvtNotes        VarChar(255)

Begin Try

    ------------------------------------------------------------------------------------------
    -- Initial @LastProcessedId from the local classification table.
    ------------------------------------------------------------------------------------------
    Select @LastProcessedId = IsNull(Max(Id), 0)
    From PharmAssist.dbo.OeOrderTextDocumentClassification;

    Set @EvtNotes = '@LastProcessedId=' + Cast(@LastProcessedId As VarChar(12))
                  + ';@NumOfRowsBatchSize=' + Cast(@LocalBatchSize As VarChar(12))
                  + ';@MaxRecords='         + Cast(@LocalMaxRecords As VarChar(12))
    Exec lsp_DbLogSqlEvent 'A', 'OEOrderTDClassify Beg', '', @EvtNotes, 'lsp_OeOrderTextDocumentsClassify'

    ------------------------------------------------------------------------------------------
    -- Batch loop driven by @@ROWCOUNT.
    ------------------------------------------------------------------------------------------
    Drop Table If Exists #BatchMax
    Create Table #BatchMax (BatchMaxId Int)

    While @ContinueLoop = 1 And @TotalProcessed < @LocalMaxRecords
    Begin
        ;With Batch As
        (
            Select Top (@LocalBatchSize)
                  Id
                , OrderId
                , HistoryDtTm
                , DataLength(DocData) As DocDataLength
            From [PWDAZNSYMPH02].PHARMASSIST.dbo.OeOrderTextDocument With (NoLock)
            Where HistoryDtTm < @CutoffDate
              And Id > @LastProcessedId
            Order By Id Asc
        )
        Insert Into PharmAssist.dbo.OeOrderTextDocumentClassification
              (Id, OrderId, DocDataLength, IsLeaflet, HistoryDtTm, ProcessedDtTm, IsDeleted)
        Output Inserted.Id Into #BatchMax (BatchMaxId)
        Select
              Id
            , OrderId
            , DocDataLength
            , Case When DocDataLength > 153600 Then 'Non-Leaflet' Else 'Leaflet' End
            , HistoryDtTm
            , GetDate()
            , 0
        From Batch;

        Set @InsertedThisPass = @@ROWCOUNT
        Set @TotalProcessed   = @TotalProcessed + @InsertedThisPass

        If @InsertedThisPass = 0
        Begin
            Set @ContinueLoop = 0
        End
        Else
        Begin
            Select @LastProcessedId = IsNull(Max(BatchMaxId), @LastProcessedId)
            From #BatchMax;

            Truncate Table #BatchMax;

            If @InsertedThisPass < @LocalBatchSize
                Set @ContinueLoop = 0
        End
    End

    Drop Table If Exists #BatchMax

    Set @EvtNotes = '@LastProcessedId=' + Cast(@LastProcessedId As VarChar(12))
                  + ';@TotalProcessed=' + Cast(@TotalProcessed As VarChar(12))
    Exec lsp_DbLogSqlEvent 'A', 'OEOrderTDClassify End', '', @EvtNotes, 'lsp_OeOrderTextDocumentsClassify'

End Try

Begin Catch

    Set @ErrorMessage  = ERROR_MESSAGE()
    Set @ErrorSeverity = ERROR_SEVERITY()
    Set @ErrorState    = ERROR_STATE()

    Set @EvtNotes = '@@ErrorSeverity=' + Cast(@ErrorSeverity As VarChar(12))
                  + ';@ErrorState='    + Cast(@ErrorState As VarChar(12))
                  + ';@ErrorMessage='  + Cast(@ErrorMessage As VarChar(200))
    Exec lsp_DbLogSqlEvent 'A', 'OEOrderTDClassify Err', '', @EvtNotes, 'lsp_OeOrderTextDocumentsClassify'

    RaisError('Error in ClassifyOeOrderTextDocuments: %s', @ErrorSeverity, @ErrorState, @ErrorMessage)

End Catch

End
GO
