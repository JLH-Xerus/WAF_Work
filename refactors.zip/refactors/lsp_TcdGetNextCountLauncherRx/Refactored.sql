--/
ALTER PROCEDURE [dbo].[lsp_TcdGetNextCountLauncherRx]
   @AddrBank VarChar(2),
   @InclFillByNotReachedPriRxs TinyInt
As
Begin
/*
Object Type:
   Stored Procedure

Object Name:
   lsp_TcdGetNextCountLauncherRx

Version:
   10

Description:
   Retrieve the "next" scheduled, auto-fill Rx that is a candidate to be counted within a
   cabinet bank.

Parameters:
   @AddrBank                   - The cabinet bank for which to return the next candidate.
   @InclFillByNotReachedPriRxs - 1 = include Fill By Not Reached priority Rxs;
                                 0 = exclude them.

Comments:
   v10 - Performance refactoring:
      1. Local-variable copies for @AddrBank and @InclFillByNotReachedPriRxs to break
         parameter sniffing. The cross-list capture shows a 6,024x worst-case-to-average
         ratio on this procedure, which is the textbook plan-volatility signature for
         parameter sniffing on a hot path.
      2. Replaced legacy `If Object_Id('TempDb..#temp') Is Not Null Drop Table #temp`
         pattern with `Drop Table If Exists #temp`.
      3. Split the main "next candidate by priority" branch into two top-level shapes
         selected by @LocalInclFillByNotReachedPriRxs (1 = include all priorities, 0 =
         exclude PriCodeSys = 60). The original collapsed both shapes into a single
         non-SARGable `PriCodeSys <> Case @InclFillByNotReachedPriRxs ...` predicate
         which prevented the optimizer from caching a tight plan per branch.
      4. Replaced `If Exists (Select * From #temp)` with `@@ROWCOUNT` check immediately
         after the INSERT. The Exists scan was re-reading the temp table after the same
         insert had just populated it.
      5. Removed the `Index(ByOrderStatusFillTypeAddrBank)` hint on OeOrder. The cleaner
         per-branch shape lets the optimizer choose the index naturally; the hint was a
         vestige of the original query's ambiguity. Retain the hint if post-deployment
         monitoring shows the optimizer choosing a different index.
      6. Pulled the inline sibling-OrderId derived table into a CTE so the derivation is
         expressed once per branch instead of nested inside the main FROM clause.
      7. Added `Option (Recompile)` on the three top-level statements. The bimodal
         parameter shape on @InclFillByNotReachedPriRxs and the highly variable selectivity
         per @AddrBank make per-call compilation cheaper than running a wrong plan.
*/

Set NoCount On

-- Local variable copies break parameter sniffing on the downstream queries.
Declare @LocalAddrBank VarChar(2) = @AddrBank
Declare @LocalInclFillByNotReachedPriRxs TinyInt = @InclFillByNotReachedPriRxs

Declare @CfgLaunchCountingOfRxGroupsTogether Bit = 0

------------------------------------------------------------------------------------------
-- Read the system-wide config param value [CountLauncher] LaunchCountingOfRxGroupsTogether
------------------------------------------------------------------------------------------
Select @CfgLaunchCountingOfRxGroupsTogether = IIF(SW.Value = 'True', 1, 0)
From vCfgSystemParamVal As SW With (NoLock)
Where SW.Section = 'CountLauncher'
  And SW.Parameter = 'LaunchCountingOfRxGroupsTogether'

------------------------------------------------------------------------------------------
-- Group-together path: when configured, prefer Scheduled Rxs whose group already has a
-- counted/counting/suspended/filled sibling. Returns the top candidate by sibling status
-- then priority date then group, and EXITS via Return when one is found.
------------------------------------------------------------------------------------------
If @CfgLaunchCountingOfRxGroupsTogether = 1
Begin
    Drop Table If Exists #temp

    -- The sibling-OrderId derivation is expressed once via a CTE rather than as an inline
    -- derived table referenced from the main FROM clause. The construction is the same.
    ;With CountedSiblings As
    (
        Select
            [SiblingOrderId] = Left(OrderId, Len(OrderId) - 2)
                             + Cast((Cast(SubString(OrderId, Len(OrderId) - 1, 1) As SmallInt) % 2) + 1 As Char(1))
                             + Right(OrderId, 1)
        From OeOrder With (NoLock)
        Where OrderStatus In ('Counting', 'Counted', 'Suspended')
          And AddrBank = @LocalAddrBank
          And OrderId Like '%<[1-2]>'
    )
    Select
          O.OrderId
        , O.InvPool
        , O.ProductId
        , O.QtyOrdered
        , O.QtyFilled
        , O.PriCodeSys
        , O.NumBuffers
        , O.OrderStatus
        , O.GroupNum
        , [PriorityDtTm] = IsNull(NullIf(CFG.DateFilled, ''), CFG.LastStatusChgDtTm)
        , [HasCountedSibling] = Case When CS.SiblingOrderId Is Null Then 0 Else 1 End
    Into #temp
    From OeOrder As O With (NoLock)
    Inner Join
    (
        -- Groups with any counted/counting/suspended Rx or any filled Rx are the
        -- candidate-group set. The inner aggregation collapses to one row per group.
        Select GroupNum, DateFilled = Max(DateFilled), LastStatusChgDtTm = Min(LastStatusChgDtTm)
        From OeOrder With (NoLock)
        Where OrderStatus In ('Counting', 'Counted', 'Suspended')
           Or DateFilled Is Not Null
        Group By GroupNum
    ) As CFG
        On O.GroupNum = CFG.GroupNum
    Left Join CountedSiblings As CS
        On O.OrderId = CS.SiblingOrderId
    Left Join TcdCountLauncherAlreadyConsideredRxs As C With (NoLock)
        On O.OrderId = C.OrderId
    Where O.OrderStatus = 'Scheduled'
      And O.FillType    = 'A'
      And O.AddrBank    = @LocalAddrBank
      And C.OrderId Is Null
    Option (Recompile)

    If @@ROWCOUNT > 0
    Begin
        Set NoCount Off

        Select Top 1 *
        From #temp With (NoLock)
        Order By
              HasCountedSibling Desc
            , PriorityDtTm Asc
            , GroupNum Asc

        Drop Table If Exists #temp
        Return
    End

    Drop Table If Exists #temp
End

------------------------------------------------------------------------------------------
-- Main path: next candidate by internal priority.
-- Split into two explicit branches so the optimizer caches a tight plan per branch
-- instead of evaluating a Case-based predicate in the WHERE clause.
------------------------------------------------------------------------------------------
If @LocalInclFillByNotReachedPriRxs = 1
Begin
    Set NoCount Off

    ;With CountedSiblings As
    (
        Select
            [SiblingOrderId] = Left(OrderId, Len(OrderId) - 2)
                             + Cast((Cast(SubString(OrderId, Len(OrderId) - 1, 1) As SmallInt) % 2) + 1 As Char(1))
                             + Right(OrderId, 1)
        From OeOrder With (NoLock)
        Where OrderStatus In ('Counting', 'Counted', 'Suspended')
          And OrderId Like '%<[1-2]>'
    )
    Select Top 1
          O.OrderId
        , O.InvPool
        , O.ProductId
        , O.QtyOrdered
        , O.QtyFilled
        , O.PriCodeSys
        , O.NumBuffers
        , O.OrderStatus
        , O.GroupNum
        , [HasCountedSibling] = Case When CS.SiblingOrderId Is Null Then 0 Else 1 End
    From OeOrder As O With (NoLock)
    Left Join CountedSiblings As CS
        On O.OrderId = CS.SiblingOrderId
    Left Join TcdCountLauncherAlreadyConsideredRxs As C With (NoLock)
        On O.OrderId = C.OrderId
    Where O.OrderStatus = 'Scheduled'
      And O.FillType    = 'A'
      And O.AddrBank    = @LocalAddrBank
      And C.OrderId Is Null
    Order By
          HasCountedSibling Desc
        , O.PriInternal
        , O.GroupNum
        , O.OrderId
    Option (Recompile)
End
Else
Begin
    Set NoCount Off

    ;With CountedSiblings As
    (
        Select
            [SiblingOrderId] = Left(OrderId, Len(OrderId) - 2)
                             + Cast((Cast(SubString(OrderId, Len(OrderId) - 1, 1) As SmallInt) % 2) + 1 As Char(1))
                             + Right(OrderId, 1)
        From OeOrder With (NoLock)
        Where OrderStatus In ('Counting', 'Counted', 'Suspended')
          And OrderId Like '%<[1-2]>'
    )
    Select Top 1
          O.OrderId
        , O.InvPool
        , O.ProductId
        , O.QtyOrdered
        , O.QtyFilled
        , O.PriCodeSys
        , O.NumBuffers
        , O.OrderStatus
        , O.GroupNum
        , [HasCountedSibling] = Case When CS.SiblingOrderId Is Null Then 0 Else 1 End
    From OeOrder As O With (NoLock)
    Left Join CountedSiblings As CS
        On O.OrderId = CS.SiblingOrderId
    Left Join TcdCountLauncherAlreadyConsideredRxs As C With (NoLock)
        On O.OrderId = C.OrderId
    Where O.OrderStatus = 'Scheduled'
      And O.FillType    = 'A'
      And O.AddrBank    = @LocalAddrBank
      And O.PriCodeSys <> 60               -- Exclude Fill By Not Reached priority Rxs
      And C.OrderId Is Null
    Order By
          HasCountedSibling Desc
        , O.PriInternal
        , O.GroupNum
        , O.OrderId
    Option (Recompile)
End

End
GO
