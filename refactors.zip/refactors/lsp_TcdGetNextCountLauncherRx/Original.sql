/****** Object:  StoredProcedure [dbo].[lsp_TcdGetNextCountLauncherRx]    Script Date: 4/5/2026 8:50:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[lsp_TcdGetNextCountLauncherRx]
  @AddrBank VarChar(2),
  @InclFillByNotReachedPriRxs TinyInt
As
Begin
/*
Object Type:
   Stored Procedure

Object Name:
   lsp_TcdGetNextCountLauncherRx

Version:
   9 

Description:
   Retrieve the "next" scheduled, auto-fill Rx that is a candidate to be counted within a
     cabinet bank.

Parameters:
   @AddrBank                   - The cabinet bank for which to return the next candidate,
                                   scheduled, auto-fill Rx.
   @InclFillByNotReachedPriRxs - True  = Include Fill By priority Rxs that have not yet
                                           matured.
                                 False = Exclude Fill By priority Rxs that have not yet
                                           matured.

Return Value:
   None

Comments:
   A cabinet bank's TCD Controller Count Launcher uses this stored procedure to retrieve
    one candidate Rx at a time in priority sequence.  As the count launcher entertains each
    Rx that cannot yet be counted (due to in use dispenser, max counting, insufficient
    dispenser quantity, etc.), it adds the Rx's Order ID (+) to table 
    TcdCountLauncherAlreadyConsideredRxs.  This stored procedure uses this table in order to
    return a "next" candidate Rx (by effectively ignoring the "already considered" Rxs).

*/

SET NOCOUNT ON

Declare @CfgCountLauncher_LaunchCountingOfRxGroupsTogether As Bit = 0

--------------------------------------------------------------------------------------------------------
-- Query for the System-Wide config param value [Count Launcher] LaunchCountingOfRxGroupsTogether
--------------------------------------------------------------------------------------------------------
Select
   @CfgCountLauncher_LaunchCountingOfRxGroupsTogether = IIF(SW.Value = 'True', 1, 0)
From
   vCfgSystemParamVal As SW With (NoLock)
Where
   SW.Section = 'CountLauncher'
   And SW.Parameter = 'LaunchCountingOfRxGroupsTogether'

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- If LaunchCountingOfRxGroupsTogether is configured, then first search for any scheduled Rxs that may have a sibling in it's group that already got it's count launched. 
-- If found then return otherwise proceed to the next select query that determines the next rx by considering the Rx internal priorities.
-- Note: Rxs present in the TcdCountLauncherAlreadyConsideredRxs will be ignored and not included in this search.
-- Priority in this selection method is determined by the least last status change date time (incase of counting/counted Rx) or the least date time filled (incase the Rx already got filled)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
If @CfgCountLauncher_LaunchCountingOfRxGroupsTogether = 1
Begin
    If OBJECT_ID('TempDb..#temp') Is Not Null
    Drop Table #temp
    Select  O.OrderId,
            O.InvPool,
            O.ProductId,
            O.QtyOrdered,
            O.QtyFilled,
            O.PriCodeSys,
            O.NumBuffers,
            O.OrderStatus,
	        O.GroupNum,
	        Case IsNULL(CountedFilledGroupsHavingScheduledRxs.DateFilled,'') When '' Then CountedFilledGroupsHavingScheduledRxs.LastStatusChgDtTm Else CountedFilledGroupsHavingScheduledRxs.DateFilled End As [PriorityDtTm],
            [HasCountedSibling] = Case IsNull(OrdersWithCountedSibling.OrderId, '') When '' Then 0 Else 1 End
    Into 
        #temp
    From 
	    OeOrder As O With (NOLOCK)
	    Inner Join
	    (Select GroupNum,DateFilled, LastStatusChgDtTm  From OeOrder With (NOLOCK) Where OrderStatus In ('Counting','Counted','Suspended') Or DateFilled IS NOT NULL) As CountedFilledGroupsHavingScheduledRxs
	    On O.GroupNum = CountedFilledGroupsHavingScheduledRxs.GroupNum
        Left Join (
            --
            -- Inner Select Table:  A list of Dual-Dispenser Portions Rxs that have counted sibling Rxs.
            --
            Select
            [OrderId] = Left(OrderId, Len(OrderId) - 2) +
                        Cast((Cast(SubString(OrderId, Len(OrderId) - 1, 1) As SmallInt) % 2) + 1 As Char(1)) +
                        Right(OrderId, 1)
            From
            OeOrder With (NoLock)
            Where
            OrderStatus In ('Counting', 'Counted', 'Suspended') And 
            AddrBank = @AddrBank And
            OrderId Like '%<[1-2]>'
        ) As OrdersWithCountedSibling
        On O.OrderId = OrdersWithCountedSibling.OrderId
	    Left Join
        TcdCountLauncherAlreadyConsideredRxs As C With (NOLOCK) 
        On O.OrderId = C.OrderId
    Where 
        C.OrderId Is Null And
	    O.OrderStatus = 'Scheduled'And
	    O.FillType = 'A' And
        O.AddrBank = @AddrBank  

    IF EXISTS (SELECT * FROM #temp)
        Begin
			SET NOCOUNT OFF
            Select Top 1 * 
            From 
                #temp With (NOLOCK) 
            Order By 
                HasCountedSibling DESC,
		        PriorityDtTm ASC,
	            GroupNum ASC

		    If OBJECT_ID('TempDb..#temp') Is Not Null
		    Drop Table #temp
			
            RETURN
        End

      If OBJECT_ID('TempDb..#temp') Is Not Null
	  Drop Table #temp

End

Begin
	SET NOCOUNT OFF
    Select
        Top 1
            O.OrderId,
            O.InvPool,
            O.ProductId,
            O.QtyOrdered,
            O.QtyFilled,
            O.PriCodeSys,
            O.NumBuffers,
            O.OrderStatus,
            O.GroupNum,
            [HasCountedSibling] = Case IsNull(OrdersWithCountedSibling.OrderId, '')
                                When '' Then 0
                                Else 1 End
    From
        OeOrder As O With (NoLock, Index(ByOrderStatusFillTypeAddrBank))
            Left Join (
                        --
                        -- Inner Select Table:  A list of Dual-Dispenser Portions Rxs that have counted sibling Rxs.
                        --
                        Select
                        [OrderId] = Left(OrderId, Len(OrderId) - 2) +
                                    Cast((Cast(SubString(OrderId, Len(OrderId) - 1, 1) As SmallInt) % 2) + 1 As Char(1)) +
                                    Right(OrderId, 1)
                        From
                        OeOrder With (NoLock)
                        Where
                        OrderStatus In ('Counting', 'Counted', 'Suspended')
                            And
                        OrderId Like '%<[1-2]>'
                    ) As OrdersWithCountedSibling
            On O.OrderId = OrdersWithCountedSibling.OrderId
            Left Join
        TcdCountLauncherAlreadyConsideredRxs As C With (NOLOCK) 
            On O.OrderId = C.OrderId
    Where
        O.OrderStatus = 'Scheduled'
            And
        O.FillType = 'A'
            And
        O.AddrBank = @AddrBank
            And
        O.PriCodeSys <>
            Case @InclFillByNotReachedPriRxs
            When 1 Then -1
            Else 60
            End                                -- Include/Exclude Fill By - Not Reached priority Rxs as specified.
            And
        C.OrderId Is Null                    -- Exclude Rxs already considered by the Count Launcher within its
                                            --   current pass of countable Rxs.
    Order By
        HasCountedSibling Desc,
        O.PriInternal,
        O.GroupNum,
        O.OrderId
End
End

GO
